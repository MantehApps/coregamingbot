import profile from './profile';
import stats from './stats';

export {
    profile as getProfile,
    stats as getStats,
}